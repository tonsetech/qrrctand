import React, { useState } from "react";
import BarcodeScannerComponent from "react-qr-barcode-scanner";
import axios from 'axios';
function App() {
  const [data, setData] = useState("Not Found");
  const [msg, setMsg] = useState("");
  const getScanCode = (body) => {
      
    const body_text = { qr_base46: body.text};
    axios.post('https://app.faatora.com/zatcaqr/api/scan' , body_text)
      .then(response => {
        setData(body.text);
        setMsg(response.data.msg)
      });
  }

  return (
    <>
      <BarcodeScannerComponent
        width={500}
        height={500}
        onUpdate={(err, result) => {
         
          if (result) {
            getScanCode(result)
              console.log(result)
          }
          else setData('not');
        }}
      />
      <p>{data}</p>
      <p>{msg}</p>
    </>
  );
}

export default App;
